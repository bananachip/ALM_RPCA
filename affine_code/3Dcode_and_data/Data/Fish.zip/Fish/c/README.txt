
This directory contains about 1100 boundary contours of fish images used
as a database for shape similarity retrieval. The details can be found 
in :

Mokhtarian, F. Abbasi S. and Kittler J. ``Robust and Efficient Shape 
Indexing through Curvature Scale Space '' in Proceedings of the sixth 
British Machine Vision Conference, BMVC'96. Edinburgh, 10-12 September 
1996,
pp 53-62.

Mokhtarian, F. Abbasi S. and Kittler J. ``Efficient and Robust 
Retrieval by Shape Content through Curvature Scale Space '' in 
Proceedings of the First International Workshop on Image Database 
and Multimedia Search, Amsterdam, The Netherlands Aug 1996, pp 35-42. 


Format:

Each file contains an object represented by the x and y coordinates of 
its boundary points. The number of these points varies from 400 to 1600 
for images in our database.

Acquisition notes:

The original color images scanned from these books:

S.Shirai
Marine animals of the Indo-Pacific V1
Shin Nippon kyoiku Tosho Co
1986 Japan
ISBN 88024-092-3 c1640

John and Gillian Lythgoe
Fishes of the sea, The North Atkantic and Mediterranean
Blandford Press
London, UK 1991
ISBN 0-7137-2225-8

Pamela Bristow (editor), from a text by Pivnicka and Karel Cerny
The illustrated book of Fishes
Octopus Books (English Publisher)
London 1987
TSNP Martin (Czech Publisher)
1987 Prague
ISBN 0-7064-2985-0

After scanning the images, which basicaly contained one object,
the boundary of each object extracted using the method 
described in the above mentioned papers.

To avoid copyright problems, we do not supply the original color 
images to public domain. 

Copyright notes:

These files can be used for research activities. We would like to ask 
the researchers to acknowledge us in the relevant publications.

Questions, comments etc. to: s.abbasi@ee.surrey.ac.uk

